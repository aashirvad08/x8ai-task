import type { Step } from "./types";

// Each run's steps load once per page session; a failed load is forgotten so the next attempt retries.
const cache = new Map<string, Promise<Step[]>>();

export function loadSteps(task: string, idx: number): Promise<Step[]> {
  const key = `${task}-${idx}`;
  let p = cache.get(key);
  if (!p) {
    p = fetch(`/data/steps/${key}.json`).then((res) => {
      if (!res.ok) throw new Error(res.status === 404 ? "This run has no recorded steps." : `Request failed (${res.status})`);
      return res.json() as Promise<Step[]>;
    });
    p.catch(() => cache.delete(key));
    cache.set(key, p);
  }
  return p;
}
