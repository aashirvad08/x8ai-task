import raw from "@/data/deck.json";
import type { Deck, SheetPayload, Task } from "./types";

// Built by scripts/build-deck.mjs. Import only from server components: pages hand each client view just the part it needs.
export const DECK = raw as unknown as Deck;

export const getTask = (id: string) => DECK.tasks.find((t) => t.id === id);

// Previous and next tasks, for moving between task decks.
export function neighbours(id: string) {
  const i = DECK.tasks.findIndex((t) => t.id === id);
  const brief = (t?: Task) => (t ? { id: t.id, name: t.name } : null);
  return { index: i, count: DECK.tasks.length, prev: brief(DECK.tasks[i - 1]), next: brief(DECK.tasks[i + 1]) };
}

// Every page of a task deck, by URL segment.
export function slideKeys(t: Task) {
  return [
    "overview",
    "details",
    "grading",
    ...(t.doc.blockers.length ? ["blockers", ...t.doc.blockers.map((_, i) => `blocker-${i + 1}`)] : []),
    "results",
    ...(t.failureModes.length ? ["failure-modes"] : []),
    "runs",
    ...t.rollouts.map((r) => `run-${r.idx}`),
  ];
}

export function sheetPayload(): SheetPayload {
  const byChecks = DECK.settings.criteria === "checks";
  return {
    title: DECK.batch.name,
    description: DECK.batch.description,
    criteria: DECK.settings.criteria,
    googleSheetUrl: DECK.settings.googleSheetUrl,
    models: DECK.models,
    tasks: DECK.tasks.map((t) => ({
      id: t.id,
      code: t.code,
      slug: t.slug,
      name: t.name,
      sourceTraceId: t.sourceTraceId,
      domain: t.domain,
      headline: t.headline,
      apps: t.doc.apps.map((a) => a.name),
      instruction: t.doc.instruction,
      blockers: t.doc.blockers.length,
      steps: t.stats.steps,
      runs: t.rollouts.map((r) => ({
        idx: r.idx,
        model: r.model,
        score: r.score,
        passed: r.passed,
        total: r.total,
        achievement: byChecks ? (r.total ? r.passed / r.total : 0) : r.score,
        completed: r.completed,
        steps: r.steps,
        summary: t.writeups.find((w) => w.rollout === r.idx)?.title ?? null,
      })),
    })),
  };
}
