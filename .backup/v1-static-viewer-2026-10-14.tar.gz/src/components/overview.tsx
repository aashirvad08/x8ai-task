"use client";

import * as React from "react";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { ModelDot } from "@/components/marks";
import { ScoresCard, ScoreSheet } from "@/components/scores";
import { fmtInt, pad2 } from "@/lib/format";
import { taskHref } from "@/lib/routes";
import type { SheetPayload } from "@/lib/types";
import { cn } from "@/lib/utils";

type TabKey = "summary" | "tasks" | "runs";

export function Overview({ payload }: { payload: SheetPayload }) {
  const [sheet, setSheet] = React.useState<TabKey | null>(null);
  const runs = payload.tasks.reduce((n, t) => n + t.runs.length, 0);
  const steps = payload.tasks.reduce((n, t) => n + t.steps, 0);
  return (
    <>
      <section className="overview-hero">
        <div className="overview-intro">
          <p className="eyebrow">Task review</p>
          <h1>{payload.title}</h1>
          <p>{payload.description}</p>
          <div className="overview-counts">
            <span>
              <strong>{payload.tasks.length}</strong> {payload.tasks.length === 1 ? "task" : "tasks"}
            </span>
            <span>
              <strong>{fmtInt(runs)}</strong> runs
            </span>
            <span>
              <strong>{fmtInt(steps)}</strong> recorded steps
            </span>
          </div>
        </div>
        <ScoresCard payload={payload} onOpen={(tab) => setSheet(tab ?? "summary")} />
      </section>

      <h2 className="eyebrow overview-label">Tasks</h2>
      <ol className="task-list">
        {payload.tasks.map((t, i) => (
          <li key={t.id}>
            <Link href={taskHref(t.id)} className="task-entry">
              <span className="task-entry-num">{pad2(i + 1)}</span>
              <div className="task-entry-body">
                <p className="meta-line mb-0">
                  <span>{t.code}</span>
                  {t.domain && <span>{t.domain}</span>}
                </p>
                <h2>{t.name}</h2>
                {t.headline && <p className="task-entry-headline">{t.headline}</p>}
                <div className="task-entry-models">
                  {payload.models.map((m) => {
                    const rs = t.runs.filter((r) => r.model === m);
                    if (!rs.length) return null;
                    const passes = rs.filter((r) => r.completed).length;
                    const ach = rs.reduce((a, r) => a + r.achievement, 0) / rs.length;
                    return (
                      <React.Fragment key={m}>
                        <span className="model-name">
                          <ModelDot model={m} all={payload.models} />
                          {m}
                        </span>
                        <span className="task-entry-score">
                          <b>{ach.toFixed(3)}</b> criteria · <span className={cn(passes > 0 && "tone-pass")}>{passes}/{rs.length}</span> passed
                        </span>
                      </React.Fragment>
                    );
                  })}
                </div>
                <span className="task-entry-foot">
                  {t.runs.length} runs · {t.blockers} blockers
                  <span className="task-entry-open">
                    Open <ArrowRight size={14} />
                  </span>
                </span>
              </div>
            </Link>
          </li>
        ))}
      </ol>
      <ScoreSheet open={sheet !== null} initialTab={sheet ?? "summary"} onClose={() => setSheet(null)} payload={payload} />
    </>
  );
}
