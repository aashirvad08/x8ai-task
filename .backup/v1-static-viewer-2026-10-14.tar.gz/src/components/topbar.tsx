"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ChevronRight } from "lucide-react";
import { SidebarToggle } from "@/components/sidebar-toggle";
import { ThemeMenu } from "@/components/theme-menu";
import raw from "@/data/nav.json";
import { taskHref } from "@/lib/routes";
import type { NavTask } from "@/lib/types";

const NAV = raw as NavTask[];

export function Topbar() {
  const path = usePathname();
  const [, section, id, sub, idx] = path.split("/");
  const task = section === "t" ? NAV.find((t) => t.id === id) : undefined;
  const run = task && sub === "r" ? task.rollouts.find((r) => r.idx === Number(idx)) : undefined;
  return (
    <header className="topbar">
      <div className="topbar-left">
        <SidebarToggle />
        <nav className="breadcrumbs" aria-label="Breadcrumb">
          {task ? (
            <>
              <Link href="/">Run Deck</Link>
              <ChevronRight size={12} />
              {run ? <Link href={taskHref(task.id)}>{task.code}</Link> : <span>{task.code}</span>}
              <ChevronRight size={12} />
              <strong>{run ? `Run ${run.idx} · ${run.model}` : task.name}</strong>
            </>
          ) : (
            <strong>All tasks</strong>
          )}
        </nav>
      </div>
      <div className="topbar-right">
        <ThemeMenu />
      </div>
    </header>
  );
}
