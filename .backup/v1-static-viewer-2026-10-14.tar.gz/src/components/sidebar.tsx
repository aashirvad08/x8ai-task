"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { LayoutGrid } from "lucide-react";
import { BrandMark } from "@/components/brand-mark";
import raw from "@/data/nav.json";
import { taskHref } from "@/lib/routes";
import type { NavTask } from "@/lib/types";
import { cn } from "@/lib/utils";

const NAV = raw as NavTask[];

export function Sidebar() {
  const path = usePathname();
  const total = NAV.reduce((n, t) => n + t.rollouts.length, 0);
  const models = [...new Set(NAV.flatMap((t) => t.rollouts.map((r) => r.model.split(" ")[0])))];
  return (
    <aside className="sidebar" aria-label="Tasks">
      <div className="sidebar-inner">
        <Link href="/" className="brand">
          <BrandMark className="brand-mark" />
          Run Deck
        </Link>
        <Link href="/" className={cn("nav-home", path === "/" && "active")}>
          <LayoutGrid size={15} /> All tasks
        </Link>
        <p className="nav-label">Tasks</p>
        <nav className="task-nav">
          {NAV.map((t) => (
            <Link key={t.id} href={taskHref(t.id)} className={cn((path === taskHref(t.id) || path.startsWith(`${taskHref(t.id)}/`)) && "active")}>
              <span className="task-nav-top">{t.code}</span>
              <strong>{t.name}</strong>
            </Link>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <span>
            <span className="local-dot" />
            {total} runs · local
          </span>
          <span>{models.join(" · ")}</span>
        </div>
      </div>
    </aside>
  );
}
