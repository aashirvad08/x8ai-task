import { notFound, redirect } from "next/navigation";
import legacy from "@/data/legacy-steps.json";
import { getTask } from "@/lib/data";
import { playerHref } from "@/lib/routes";

type Params = { task: string; model: string; run: string };

// Old run pages (/run/h937/fable/run1?step=12) now live in the player; their step numbers counted turns, not actions.
export default async function LegacyRun({ params, searchParams }: { params: Promise<Params>; searchParams: Promise<{ step?: string }> }) {
  const p = await params;
  const { step } = await searchParams;
  const task = getTask(p.task);
  const r = task?.rollouts.find((x) => x.run === p.run && x.model.toLowerCase().startsWith(p.model));
  if (!task || !r) notFound();
  const turns = (legacy as Record<string, number[]>)[`${task.id}-${r.idx}`];
  const turn = Number(step);
  redirect(playerHref(task.id, r.idx, turns && turn >= 1 ? turns[Math.min(turns.length, turn) - 1] : undefined));
}
