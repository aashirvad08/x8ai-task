import { sheetPayload } from "@/lib/data";
import { playerHref, taskHref } from "@/lib/routes";
import { buildSheet, toCsv } from "@/lib/sheet";

// One tab of the scores sheet as CSV, for Google Sheets' IMPORTDATA: /api/sheet.csv?tab=summary|tasks|runs
export function GET(request: Request) {
  const url = new URL(request.url);
  const key = url.searchParams.get("tab") ?? "summary";
  const tabs = buildSheet(sheetPayload(), {
    taskUrl: (t) => `${url.origin}${taskHref(t)}`,
    runUrl: (t, idx) => `${url.origin}${playerHref(t, idx)}`,
  });
  const tab = tabs.find((t) => t.key === key);
  if (!tab) return Response.json({ error: `Unknown tab "${key}". Use summary, tasks or runs.` }, { status: 404 });
  return new Response(toCsv(tab), {
    headers: { "Content-Type": "text/csv; charset=utf-8", "Cache-Control": "no-store" },
  });
}
