import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { Sidebar } from "@/components/sidebar";
import { ToastProvider } from "@/components/toast";
import { Topbar } from "@/components/topbar";
import "./globals.css";

const geistSans = Geist({ variable: "--font-geist-sans", subsets: ["latin"] });
const geistMono = Geist_Mono({ variable: "--font-geist-mono", subsets: ["latin"] });

export const metadata: Metadata = {
  title: { default: "Run Deck", template: "%s · Run Deck" },
  description: "Fable and Sol computer-use runs on five tasks: each task as a deck (instruction, grading, blockers, results, failure modes, write-ups) and every run in a step-by-step player.",
};

// Applies the saved theme and sidebar state before paint so the page never flashes the wrong colours or layout.
const themeScript = `try{var d=document.documentElement;if(localStorage.getItem("theme")==="dark")d.dataset.theme="dark";if(localStorage.getItem("sidebar")==="collapsed")d.dataset.sidebar="collapsed"}catch(e){}`;

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" suppressHydrationWarning className={`${geistSans.variable} ${geistMono.variable}`}>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body>
        <ToastProvider>
          <div className="app-shell">
            <Sidebar />
            <div className="workspace-main">
              <Topbar />
              <main className="workspace-content">{children}</main>
            </div>
          </div>
        </ToastProvider>
      </body>
    </html>
  );
}
