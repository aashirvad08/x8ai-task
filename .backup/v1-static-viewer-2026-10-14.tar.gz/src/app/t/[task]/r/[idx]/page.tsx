import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Player } from "@/components/player/player";
import { DECK, getTask } from "@/lib/data";

type Params = { task: string; idx: string };

export const dynamicParams = false;

export function generateStaticParams(): Params[] {
  return DECK.tasks.flatMap((t) => t.rollouts.map((r) => ({ task: t.id, idx: String(r.idx) })));
}

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const { task: id, idx } = await params;
  const task = getTask(id);
  return { title: task ? `Run ${idx} · ${task.name}` : "Run" };
}

export default async function PlayerPage({ params }: { params: Promise<Params> }) {
  const { task: id, idx } = await params;
  const task = getTask(id);
  const n = Number(idx);
  if (!task || !task.rollouts.some((r) => r.idx === n)) notFound();
  return <Player key={`${id}:${n}`} task={task} idx={n} />;
}
