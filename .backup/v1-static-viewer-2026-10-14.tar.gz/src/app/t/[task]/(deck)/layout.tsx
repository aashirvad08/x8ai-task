import { notFound } from "next/navigation";
import { Deck } from "@/components/deck/deck";
import { getTask, neighbours } from "@/lib/data";

// The deck lives in the layout so moving between its pages keeps the contents panel and any open step in place.
export default async function DeckLayout({ children, params }: { children: React.ReactNode; params: Promise<{ task: string }> }) {
  const { task: id } = await params;
  const task = getTask(id);
  if (!task) notFound();
  return (
    <>
      <Deck task={task} nav={neighbours(id)} />
      {children}
    </>
  );
}
