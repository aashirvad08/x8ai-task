import type { Metadata } from "next";
import { DECK, getTask, slideKeys } from "@/lib/data";

type Params = { task: string; slide?: string[] };

export function generateStaticParams(): Params[] {
  return DECK.tasks.flatMap((t) => [{ task: t.id, slide: [] }, ...slideKeys(t).map((k) => ({ task: t.id, slide: [k] }))]);
}

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const { task: id } = await params;
  return { title: getTask(id)?.name ?? "Task" };
}

// The deck itself renders in the layout; each page only gives the URL its own entry.
export default function DeckPage() {
  return null;
}
