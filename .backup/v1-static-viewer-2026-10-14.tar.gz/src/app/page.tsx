import { Overview } from "@/components/overview";
import { sheetPayload } from "@/lib/data";

export default function Home() {
  return <Overview payload={sheetPayload()} />;
}
